(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[0],{

/***/ "./src/intl.ts":
/*!*********************!*\
  !*** ./src/intl.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var intl__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! intl */ "./node_modules/intl/index.js");
/* harmony import */ var intl__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(intl__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var intl_locale_data_jsonp_en__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! intl/locale-data/jsonp/en */ "./node_modules/intl/locale-data/jsonp/en.js");
/* harmony import */ var intl_locale_data_jsonp_en__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(intl_locale_data_jsonp_en__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var intl_locale_data_jsonp_ru__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! intl/locale-data/jsonp/ru */ "./node_modules/intl/locale-data/jsonp/ru.js");
/* harmony import */ var intl_locale_data_jsonp_ru__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(intl_locale_data_jsonp_ru__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var intl_locale_data_jsonp_ja__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! intl/locale-data/jsonp/ja */ "./node_modules/intl/locale-data/jsonp/ja.js");
/* harmony import */ var intl_locale_data_jsonp_ja__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(intl_locale_data_jsonp_ja__WEBPACK_IMPORTED_MODULE_3__);





/***/ }),

/***/ 1:
/*!*******************************************!*\
  !*** ./locale-data/complete.js (ignored) ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ })

}]);
//# sourceMappingURL=0.js.map